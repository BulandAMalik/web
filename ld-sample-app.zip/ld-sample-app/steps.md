1. create a sample app ```npx create-react-app ld-sample-app```
2. install LD react lcient sdk ```npm install launchdarkly-react-client-sdk (https://docs.launchdarkly.com/sdk/client-side/react/react-web)```
3. install `npm install react-router-dom`
4. Configure .env with following properties

        ``` 
        pn.launchdarkly.clientId=
        ```
5. Read this doc carefully `https://docs.launchdarkly.com/sdk/client-side/react/react-web`
6. You can install VCode LaunchDarkly extention. VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=LaunchDarklyOfficial.launchdarkly
7. 